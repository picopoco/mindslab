# k_maum text
w